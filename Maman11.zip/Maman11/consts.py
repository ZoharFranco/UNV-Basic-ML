from models.matrix import Matrix

EMPTY_CELL = -1
TARGET_MATRIX = Matrix([[EMPTY_CELL, 1, 2], [3, 4, 5], [6, 7, 8]])
